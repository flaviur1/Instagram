import React from 'react';

const PostCard = ({ post }) => {
    return (
        <div className="post-card">
            <h3>{post.title}</h3>
            <p>{post.text}</p>
            {post.image && <img src={post.image} alt="post" />}
            <p>By {post.author} on {new Date(post.created_at).toLocaleString()}</p>
            <p>Status: {post.status}</p>
            <div>Tags: {post.tags.join(', ')}</div>
        </div>
    );
};

export default PostCard;
