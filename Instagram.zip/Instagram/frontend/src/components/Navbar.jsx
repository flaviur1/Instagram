import React from 'react';

const Navbar = () => {
    return (
        <nav className="navbar">
            <h2>Pinstagram</h2>
            <input type="text" placeholder="Search posts..." />
            <div className="nav-links">
                <a href="/profile">My Profile</a>
                <a href="/create">Create Post</a>
            </div>
        </nav>
    );
};

export default Navbar;
