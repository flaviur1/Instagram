import axios from 'axios';

const API_BASE = 'http://localhost:8000'; // sau alt port, în funcție de backend

export const fetchPosts = async () => {
    const response = await axios.get(`${API_BASE}/posts`);
    return response.data;
};
